﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfoToJson.Engine
{
	class Field
	{
	}
}
